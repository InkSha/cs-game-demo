Font that was used for the preview:
https://www.dafont.com/highway-gothic.font
Texture that was used for the background of the preview:
https://texturehaven.com/tex/?t=castle_brick_02_red